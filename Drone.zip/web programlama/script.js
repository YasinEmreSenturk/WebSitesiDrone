
window.onscroll = function() {sayfaKaydirmaFonksiyonu()};

function sayfaKaydirmaFonksiyonu() {
  if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
    document.getElementById("sayfaBasinaGitBtn").style.display = "block";
  } else {
    document.getElementById("sayfaBasinaGitBtn").style.display = "none";
  }
}

// Yukarı kaydırma fonksiyonu
function sayfayiEnBasinaKaydir() {
  document.body.scrollTop = 0; 
  document.documentElement.scrollTop = 0; // Diğer  tüm tarayıcılar 
  //on scrolltop en üste cıkmak için oluyor.
}

function karanlikModuDegistir() {
  const body = document.body;
  body.classList.toggle("karanlik-mod");
  
  // Mod değiştirme 
  const modDegistirBtn = document.getElementById("modDegistirBtn");
  if (body.classList.contains("karanlik-mod")) {
    modDegistirBtn.textContent = "Aydınlık Mod";
  } else {
    modDegistirBtn.textContent = "Karanlık Mod";
  }
}
function togglePopup() {
  var popup = document.getElementById("popup");
  popup.style.display = popup.style.display === "none" ? "block" : "none";
}


const portfolyoOgeleri = document.querySelectorAll('.portfolio-item');


portfolyoOgeleri.forEach(item => {
   
    item.addEventListener('click', () => {
        // portföy öğesinin içindeki resmi seç
        const resim = item.querySelector('img');

        
        const yeniResimURL = 'trak.png';
        


        resim.src = yeniResimURL;
    });
});

 

    function showGif() {
    var gifImg = document.getElementById("gifImg");
    gifImg.style.display = "block"; // Gif görünür hale getirilir

    // 3 saniye sonra gif gizlenir
    setTimeout(function(){
        gifImg.style.display = "none";
    }, 11000);
}


hello();
goodbye();

function hello(){
  setTimeout(function(){
    console.log("hello !");

  }, 3000);
}
function goodbye(){

  console.log("goodbye!");
}

function walkdog(){
  return "Dog walked";
}

function cleankitchen(){
  return "Kitchen cleaned";
}

function takeOutTrash(){
  return "Trash taken out";
}

async function doChores(){
  const walkdogResult = await walkdog();
  console.log(walkdogResult);
  
  const cleankitchenResult = await cleankitchen();
  console.log(cleankitchenResult);
  
  const takeOutTrashResult = await takeOutTrash();
  console.log(takeOutTrashResult);

  console.log("You finish");
}

doChores();


function walkDog(){
    return new Promise((resolve, reject) => {
        setTimeout(() => {

            const dogWalked = false;

            if(dogWalked){
                resolve("You walk the dog🐕‍🦺");
            }
            else{
                reject("You DIDN'T walk the dog");
            }
        }, 1500);
    });
}
walkdog();

// Gizle/Göster işlevselliği için JavaScript

// Bir öğenin ID'sine göre görünürlüğünü değiştiren bir fonksiyon
function gorunurluguDegistir(elementId) {
    var element = document.getElementById(elementId);
    if (element.style.display === "none") {
        element.style.display = "block";
    } else {
        element.style.display = "none";
    }
}

function paketSeciminiGosterGizle() {
    gorunurluguDegistir('GümüsPaket'); // Paket seçimini içeren öğenin ID'si
}

function rastgeleSayiUret() {
    // 1 ile 100 arasında rastgele bir tam sayı üretme
    var rastgeleSayi = Math.floor(Math.random() * 100) + 1;
    
    // Fiyatı binlik şekilde biçimlendirme
    var formattedPrice = new Intl.NumberFormat('tr-TR').format(rastgeleSayi * 1000);

    // Sonucu HTML içeriğine yerleştirme
    document.getElementById("sonuc").innerHTML = "Fiyat: " + formattedPrice;

    // Butonu gizle
    document.getElementById("rastgeleButon").style.display = "none";

    // Butona basıldığında mesajı görüntüle ve butonu gizle
    document.getElementById("mesaj").innerHTML = "Yeni bir sayı üretmek için mesaja tıklayın.";
}


// Mesaja tıklanınca butonu gösterme işlevi
function butonuGoster() {
    // Butonu göster
    document.getElementById("rastgeleButon").style.display = "block";

    // Sonucu temizle
    document.getElementById("sonuc").innerHTML = "";
}
function formuKontrolEt() {
  var kullaniciAdi = document.getElementById("kullaniciAdi").value;
  var eposta = document.getElementById("eposta").value;
  var sifre = document.getElementById("sifre").value;
  var tcKimlik = document.getElementById("tcKimlik").value;
  var hataMesaji = document.getElementById("hataMesaji");

  // Kullanıcı adı, e-posta, şifre ve TC kimlik numarasının boş olup olmadığını kontrol et
  if (kullaniciAdi.trim() === "" || eposta.trim() === "" || sifre.trim() === "" || tcKimlik.trim() === "") {
    hataMesaji.textContent = "Lütfen tüm alanları doldurun.";
    return;
  }

  // E-posta adresinin geçerli olup olmadığını kontrol et
  if (!isValidEmail(eposta)) {
    hataMesaji.textContent = "Geçerli bir e-posta adresi girin.";
    return;
  }

  // Şifrenin en az 6 karakterden oluştuğunu kontrol et
  if (sifre.length < 6) {
    hataMesaji.textContent = "Şifre en az 6 karakterden oluşmalıdır.";
    return;
  }
  
  // TC kimlik numarasının geçerli olup olmadığını kontrol et
  if (!isValidTC(tcKimlik)) {
    hataMesaji.textContent = "Geçerli bir TC Kimlik Numarası girin.";
    return;
  }

  // Kullanıcı adının en az 8 karakterden oluştuğunu kontrol et
  if (kullaniciAdi.length < 8) {
    hataMesaji.textContent = "Kullanıcı adı en az 8 karakterden oluşmalıdır.";
    return;
  }

  // Buraya kadar herhangi bir hata yoksa formu gönder
  hataMesaji.textContent = ""; // Hata mesajını temizle
  alert("Form başarıyla gönderildi.");
}

// E-posta adresinin geçerli olup olmadığını kontrol eden fonksiyon
function isValidEmail(email) {
  var regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
}

// TC kimlik numarasının geçerli olup olmadığını kontrol eden fonksiyon
function isValidTC(tc) {
  // TC kimlik numarasının uzunluğunu kontrol et
  if (tc.length !== 11) {
    return false;
  }
  
  // TC kimlik numarasının tamamen rakam olup olmadığını kontrol et
  if (!/^\d+$/.test(tc)) {
    return false;
  }

  // İlk rakamın sıfır olmadığını kontrol et
  if (tc.charAt(0) === '0') {
    return false;
  }

  // TC kimlik numarasının belirli bir formülü karşılayıp karşılamadığını kontrol et
  var total = 0;
  for (var i = 0; i < 10; i++) {
    total += parseInt(tc.charAt(i), 10);
  }
  if (total % 10 !== parseInt(tc.charAt(10), 10)) {
    return false;
  }

  return true;
  console.log(isValidTC("12345678901")); // true (Geçerli bir TC kimlik numarası)
console.log(isValidTC("98765432100")); // false (Geçersiz bir TC kimlik numarası)

}




function gizleGoster() {
  var hesapMakinesi = document.getElementById("hesapMakinesi");
  hesapMakinesi.classList.toggle("gizli");
}

function ekranaEkle(deger) {
  document.getElementById("ekran").value += deger;
}

function hesapla() {
  var ekranDegeri = document.getElementById("ekran").value;
  var sonuc = eval(ekranDegeri);
  document.getElementById("ekran").value = sonuc;
}

function temizle() {
  document.getElementById("ekran").value = "";
}

function toggleCarpimTablosu() {
            var tablo = document.getElementById("carpimTablosu");
            if (tablo.classList.contains("gizli")) {
                tablo.classList.remove("gizli");
                carpimTablosunuOlustur(10, 10); // Varsayılan olarak 10x10 tablo oluştur
            } else {
                tablo.classList.add("gizli");
            }
        }

        function carpimTablosunuOlustur(satirSayisi, sutunSayisi) {
            var tablo = document.getElementById("carpimTablosu");
            tablo.innerHTML = ""; // Tabloyu temizle

            // Tablo başlığı oluştur
            var baslikSatiri = document.createElement("tr");
            baslikSatiri.innerHTML = "<th>x</th>"; // İlk hücre boş olacak
            for (var i = 1; i <= sutunSayisi; i++) {
                baslikSatiri.innerHTML += "<th>" + i + "</th>";
            }
            tablo.appendChild(baslikSatiri);

            // Çarpım tablosunu oluştur
            for (var i = 1; i <= satirSayisi; i++) {
                var satir = document.createElement("tr");
                satir.innerHTML = "<td>" + i + "</td>"; // İlk hücre satır numarası olacak
                for (var j = 1; j <= sutunSayisi; j++) {
                    satir.innerHTML += "<td>" + (i * j) + "</td>";
                }
                tablo.appendChild(satir);
            }
        }


let gizli = true;
let hakSayisi = 3;
let dogruSayi = Math.floor(Math.random() * 10) + 1;

function tahminEt() {
    let tahmin = parseInt(document.getElementById("tahmin").value);
    let sonuc = document.getElementById("sonuc");

    if (tahmin === dogruSayi) {
        sonuc.textContent = "Tebrikler! Doğru tahmin ettiniz.";
        sonuc.style.color = "green";
        yeniOyun();
    } else {
        hakSayisi--;
        document.getElementById("kalan-hak").textContent = hakSayisi;

        if (hakSayisi === 0) {
            sonuc.textContent = `Üzgünüz! Hakkınız kalmadı. Doğru cevap: ${dogruSayi}`;
            sonuc.style.color = "red";
            yeniOyun();
        } else {
            sonuc.textContent = "Yanlış tahmin. Tekrar deneyin.";
            sonuc.style.color = "red";
        }
    }
}

function yeniOyun() {
    hakSayisi = 3;
    dogruSayi = Math.floor(Math.random() * 10) + 1;
    document.getElementById("tahmin").value = "";
    document.getElementById("kalan-hak").textContent = hakSayisi;
    document.getElementById("sonuc").textContent = "";
}
function toggleOyun() {
    var oyunAlani = document.getElementById("oyun-alani");
    if (oyunAlani.style.display === "none") {
        oyunAlani.style.display = "block";
    } else {
        oyunAlani.style.display = "none";
    }
}

let slideIndex = 0;
const slides = document.querySelectorAll('.portfolio-item');

function showSlide(index) {
    if (index < 0) {
        slideIndex = slides.length - 1;
    } else if (index >= slides.length) {
        slideIndex = 0;
    }

    slides.forEach(slide => {
        slide.style.display = 'none'; // Tüm slaytları gizle
    });

    slides[slideIndex].style.display = 'block'; // İstenilen slaytı göster
}

function nextSlide() {
    showSlide(++slideIndex);
}

function prevSlide() {
    showSlide(--slideIndex);
}

// Otomatik geçiş için setInterval kullanabilirsiniz
// setInterval(nextSlide, 3000);

// Düğmeleri etkinleştirme
document.getElementById('prevBtn').addEventListener('click', prevSlide);
document.getElementById('nextBtn').addEventListener('click', nextSlide);

// İlk slaytı göster
showSlide(slideIndex);


